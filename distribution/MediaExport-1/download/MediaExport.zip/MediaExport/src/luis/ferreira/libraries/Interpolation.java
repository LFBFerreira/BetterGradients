package luis.ferreira.libraries;

import processing.core.PApplet;

import java.util.List;

public class Interpolation{
    // -----------------------------------------------------------------------------------------------------------------

    // RGB

    public static float[] smootherStepRgb(float[] a, float[] b, float st, float[] out) {
        float eval = smootherStep(st);
        out[0] = a[0] + eval * (b[0] - a[0]);
        out[1] = a[1] + eval * (b[1] - a[1]);
        out[2] = a[2] + eval * (b[2] - a[2]);
        out[3] = a[3] + eval * (b[3] - a[3]);
        return out;
    }

    public static float[] smootherStepRgb(float[][] arr, float st, float[] out) {
        int sz = arr.length;
        if (sz == 1 || st < 0) {
            out = java.util.Arrays.copyOf(arr[0], 0);
            return out;
        } else if (st > 1) {
            out = java.util.Arrays.copyOf(arr[sz - 1], 0);
            return out;
        }
        float scl = st * (sz - 1);
        int i = (int) scl;
        float eval = smootherStep(scl - i);
        out[0] = arr[i][0] + eval * (arr[i + 1][0] - arr[i][0]);
        out[1] = arr[i][1] + eval * (arr[i + 1][1] - arr[i][1]);
        out[2] = arr[i][2] + eval * (arr[i + 1][2] - arr[i][2]);
        out[3] = arr[i][3] + eval * (arr[i + 1][3] - arr[i][3]);
        return out;
    }


    // -----------------------------------------------------------------------------------------------------------------

    // HSB

    public static float[] smootherStepHsb(float[] a, float[] b, float st, float[] out) {

        // Find difference in hues.
        float huea = a[0];
        float hueb = b[0];
        float delta = hueb - huea;

        // Prefer shortest distance.
        if (delta < -0.5) {
            hueb += 1.0;
        } else if (delta > 0.5) {
            huea += 1.0;
        }

        float eval = smootherStep(st);

        // The two hues may be outside of 0 .. 1 range,
        // so modulate by 1.
        out[0] = (huea + eval * (hueb - huea)) % 1;
        out[1] = a[1] + eval * (b[1] - a[1]);
        out[2] = a[2] + eval * (b[2] - a[2]);
        out[3] = a[3] + eval * (b[3] - a[3]);
        return out;
    }

    public static float[] smootherStepHsb(float[][] arr, float st, float[] out) {

        int sz = arr.length;

        if (sz == 1 || st < 0) {
            out = java.util.Arrays.copyOf(arr[0], 0);
            return out;
        } else if (st > 1) {
            out = java.util.Arrays.copyOf(arr[sz - 1], 0);
            return out;
        }

        float scl = st * (sz - 1);
        int i = (int) scl;
        float huea = arr[i][0];
        float hueb = arr[i + 1][0];
        float delta = hueb - huea;

        if (delta < -0.5) {
            hueb += 1.0 / (sz - 1.0);
        } else if (delta > 0.5) {
            huea += 1.0 / (sz - 1.0);
        }

        float eval = smootherStep(scl - i);
        out[0] = (huea + eval * (hueb - huea)) % 1;
        out[1] = arr[i][1] + eval * (arr[i + 1][1] - arr[i][1]);
        out[2] = arr[i][2] + eval * (arr[i + 1][2] - arr[i][2]);
        out[3] = arr[i][3] + eval * (arr[i + 1][3] - arr[i][3]);

        return out;
    }

    // -----------------------------------------------------------------------------------------------------------------

    public static float smootherStep(float st) {
        return st * st * st * (st * (st * 6.0f - 15.0f) + 10.0f);
    }

    // -----------------------------------------------------------------------------------------------------------------

    public static int lerpColorWrapper(int[] arr, float step, int colorMode, PApplet parent) {
        int sz = arr.length;
        if (sz == 1 || step <= 0.0) {
            return arr[0];
        } else if (step >= 1.0) {
            return arr[sz - 1];
        }

        float scl = step * (sz - 1);
        int i = (int) scl;
        return parent.lerpColor(arr[i], arr[i + 1], scl - i, colorMode);
    }

    public static int lerpColorWrapper(Gradient grad, float step, int colorMode, PApplet parent) {
        return lerpColorWrapper(grad.colorStops.stream().mapToInt((ColorStop st)->st.clr).toArray(), step, colorMode, parent);
    }
}

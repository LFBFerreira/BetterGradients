package luis.ferreira.libraries;

import processing.core.*;


public class GradientTools {

    private final PApplet parent;

    public GradientTools(PApplet parent)
    {
        this.parent = parent;
    }
}


package luis.ferreira.libraries;


public class ColorComposition {
    public static int composeclr(float[] in) {
        return composeclr(in[0], in[1], in[2], in[3]);
    }

    // Assumes that RGBA are in range 0 .. 1.
    public static int composeclr(float red, float green, float blue, float alpha) {
        return Math.round(alpha * 255.0f) << 24
                | Math.round(red * 255.0f) << 16
                | Math.round(green * 255.0f) << 8
                | Math.round(blue * 255.0f);
    }

    public static int[] composeclr(float[][] in) {
        int sz = in.length;
        int [] out = new int[sz];
        for (int i = 0; i < sz; ++i) {
            out[i] = composeclr(in[i][0], in[i][1], in[i][2], in[i][3]);
        }
        return out;
    }

    // -----------------------------------------------------------------------------------------------------------------


    public static float[] decomposeclr(int clr) {
        return decomposeclr(clr, new float[]{0.0f, 0.0f, 0.0f, 1.0f});
    }

    // Assumes that out has 4 elements.
    // 1.0 / 255.0 = 0.003921569
    public static float[] decomposeclr(int clr, float[] out) {
        out[3] = (clr >> 24 & 0xff) * 0.003921569f;
        out[0] = (clr >> 16 & 0xff) * 0.003921569f;
        out[1] = (clr >> 8 & 0xff) * 0.003921569f;
        out[2] = (clr & 0xff) * 0.003921569f;
        return out;
    }
}


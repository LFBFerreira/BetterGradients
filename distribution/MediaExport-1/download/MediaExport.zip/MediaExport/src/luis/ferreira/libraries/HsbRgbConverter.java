package luis.ferreira.libraries;

public class HsbRgbConverter {

    // -----------------------------------------------------------------------------------------------------------------

    // HSB to RGB

    public static float[] hsbToRgb(float[] in) {
        float[] out = new float[]{0.0f, 0.0f, 0.0f, 1.0f};
        return hsbToRgb(in[0], in[1], in[2], in[3], out);
    }

    public static float[] hsbToRgb(float[] in, float[] out) {
        if (in.length == 3) {
            return hsbToRgb(in[0], in[1], in[2], 1.0f, out);
        } else if (in.length == 4) {
            return hsbToRgb(in[0], in[1], in[2], in[3], out);
        }
        return out;
    }

    public static float[] hsbToRgb(float hue, float sat, float bri, float alpha) {
        float[] out = new float[]{0.0f, 0.0f, 0.0f, 1.0f};
        return hsbToRgb(hue, sat, bri, alpha, out);
    }

    public static float[] hsbToRgb(float hue, float sat, float bri, float alpha, float[] out) {
        if (sat == 0.0) {

            // 0.0 saturation is grayscale, so all values are equal.
            out[0] = out[1] = out[2] = bri;
        } else {

            // Divide color wheel into 6 sectors.
            // Scale up hue to 6, convert to sector index.
            float h = hue * 6.0f;
            int sector = (int) h;

            // Depending on the sector, three tints will
            // be distributed among R, G, B channels.
            float tint1 = bri * (1.0f - sat);
            float tint2 = bri * (1.0f - sat * (h - sector));
            float tint3 = bri * (1.0f - sat * (1.0f + sector - h));

            switch (sector) {
                case 1:
                    out[0] = tint2;
                    out[1] = bri;
                    out[2] = tint1;
                    break;
                case 2:
                    out[0] = tint1;
                    out[1] = bri;
                    out[2] = tint3;
                    break;
                case 3:
                    out[0] = tint1;
                    out[1] = tint2;
                    out[2] = bri;
                    break;
                case 4:
                    out[0] = tint3;
                    out[1] = tint1;
                    out[2] = bri;
                    break;
                case 5:
                    out[0] = bri;
                    out[1] = tint1;
                    out[2] = tint2;
                    break;
                default:
                    out[0] = bri;
                    out[1] = tint3;
                    out[2] = tint1;
            }
        }

        out[3] = alpha;
        return out;
    }

    // -----------------------------------------------------------------------------------------------------------------

    // RGB to HSB

    public static float[] rgbToHsb(int clr) {
        return rgbToHsb(clr, new float[]{0.0f, 0.0f, 0.0f, 1.0f});
    }

    public static float[] rgbToHsb(int clr, float[] out) {
        return rgbToHsb((clr >> 16 & 0xff) * 0.003921569f,
                (clr >> 8 & 0xff) * 0.003921569f,
                (clr & 0xff) * 0.003921569f,
                (clr >> 24 & 0xff) * 0.003921569f, out);
    }

    public static float[] rgbToHsb(float[] in) {
        return rgbToHsb(in, new float[]{0.0f, 0.0f, 0.0f, 1.0f});
    }

    public static float[] rgbToHsb(float[] in, float[] out) {
        if (in.length == 3) {
            return rgbToHsb(in[0], in[1], in[2], 1.0f, out);
        } else if (in.length == 4) {
            return rgbToHsb(in[0], in[1], in[2], in[3], out);
        }
        return out;
    }

    public static float[] rgbToHsb(float red, float green, float blue, float alpha, float[] out) {

        // Find highest and lowest values.
        float max = Math.max(red, Math.max(green, blue));
        float min = Math.min(red, Math.min(green, blue));

        // Find the difference between max and min.
        float delta = max - min;

        // Calculate hue.
        float hue = 0.0f;
        if (delta != 0.0f) {
            if (red == max) {
                hue = (green - blue) / delta;
            } else if (green == max) {
                hue = 2.0f + (blue - red) / delta;
            } else {
                hue = 4.0f + (red - green) / delta;
            }

            hue /= 6.0;
            if (hue < 0.0) {
                hue += 1.0;
            }
        }

        out[0] = hue;
        out[1] = max == 0.0f ? 0.0f : (max - min) / max;
        out[2] = max;
        out[3] = alpha;
        return out;
    }
}
